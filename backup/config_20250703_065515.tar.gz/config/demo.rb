# Demo Environment Configuration for dentalsystem-demo
# デモ環境専用設定ファイル

Rails.application.configure do
  # Production settings as base
  config.cache_classes = true
  config.eager_load = true
  config.consider_all_requests_local = false
  config.public_file_server.enabled = ENV['RAILS_SERVE_STATIC_FILES'].present?
  config.assets.compile = false
  config.assets.digest = true
  config.force_ssl = true
  
  # Demo-specific configurations
  config.demo_mode = true
  config.log_level = :info
  
  # Demo data settings
  config.demo_patients_count = 50
  config.demo_appointments_count = 200
  config.demo_staff_count = 5
  
  # Demo restrictions
  config.demo_max_patients_per_day = 20
  config.demo_max_appointments_per_hour = 4
  config.demo_data_reset_interval = 24.hours
  
  # Demo notifications (disabled for demo)
  config.demo_disable_email = true
  config.demo_disable_sms = true
  config.demo_disable_line = false # Keep LINE for demo
  
  # Demo security (relaxed for demonstration)
  config.demo_allow_signup = true
  config.demo_max_users = 10
  
  # Cache store for demo
  config.cache_store = :memory_store, { size: 64.megabytes }
  
  # Demo database settings
  config.active_record.dump_schema_after_migration = false
  
  # Demo asset host
  config.asset_host = ENV['DEMO_ASSET_HOST'] if ENV['DEMO_ASSET_HOST'].present?
  
  # Demo error handling
  config.consider_all_requests_local = false
  config.action_controller.perform_caching = true
  
  # Demo mailer settings
  config.action_mailer.perform_caching = false
  config.action_mailer.raise_delivery_errors = false
  config.action_mailer.default_url_options = { 
    host: ENV.fetch('DEMO_HOST', 'dentalsystem-demo.railway.app'),
    protocol: 'https'
  }
  
  # Demo logging
  config.log_formatter = ::Logger::Formatter.new
  if ENV['RAILS_LOG_TO_STDOUT'].present?
    logger = ActiveSupport::Logger.new(STDOUT)
    logger.formatter = config.log_formatter
    config.logger = ActiveSupport::TaggedLogging.new(logger)
  end
  
  # Demo Active Record settings
  config.active_record.verbose_query_logs = false
end

# Demo mode flag for application
ENV['DEMO_MODE'] = 'true'
Rails.application.routes.draw do
  # ヘルスチェック
  get "/health", to: proc { [200, {"Content-Type" => "text/plain"}, ["OK"]] }
  get "/_ah/health", to: proc { [200, {"Content-Type" => "text/plain"}, ["healthy"]] }
  
  # ベータアクセス
  get '/beta', to: 'beta_login#new', as: :beta_login
  post '/beta/login', to: 'beta_login#create'
  delete '/beta/logout', to: 'beta_login#logout', as: :beta_logout
  
  # メインアプリケーション
  root 'dashboard#index'
  
  # 患者管理
  resources :patients do
    resources :appointments
    resources :treatments
    collection do
      get :search
    end
  end
  
  # 予約管理
  resources :appointments do
    member do
      patch :confirm
      patch :cancel
    end
    collection do
      get :calendar
      get :search_patients
    end
  end
  
  # フィードバック
  post '/beta/feedback', to: 'beta_feedback#create', as: :beta_feedback
  
  # デモデータリセット
  post '/beta/reset', to: 'beta#reset_demo_data', as: :reset_demo_data
end
